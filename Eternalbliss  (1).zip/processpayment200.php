<?php
// Paystack secret key
$secretKey = 'sk_live_86fcee14d403288d8fd5c991850896d1b68e225a';

$data = json_decode(file_get_contents('php://input'), true);
$reference = $data['reference'] ?? '';

// Verify payment with Paystack
$url = "https://api.paystack.co/transaction/verify/" . $reference;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer " . $secretKey
]);
$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

if ($result['status'] && $result['data']['status'] == 'success') {
    $amount = $result['data']['amount'] / 100; // Convert from kobo to Naira
    $userId = $data['user_id'];
    $plan = $data['plan'];
    
    // Update user subscription in database
    $stmt = $pdo->prepare("INSERT INTO subscriptions (user_id, plan, amount, start_date, end_date) VALUES (?, ?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 1 MONTH))");
    if ($stmt->execute([$userId, $plan, $amount])) {
        echo json_encode(['status' => 'success', 'message' => 'Payment processed successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update subscription']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Payment verification failed']);
}
?>